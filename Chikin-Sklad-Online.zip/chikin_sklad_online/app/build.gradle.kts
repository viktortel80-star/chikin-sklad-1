plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.chikinsklad"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.chikinsklad"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

kotlinOptions { jvmTarget = "17" }

// Compose is intentionally not used: this keeps the project simple for online building.
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
