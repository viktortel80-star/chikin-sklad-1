package com.example.chikinsklad

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val p by lazy { getSharedPreferences("data", MODE_PRIVATE) }
    private val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); main() }

    private fun main() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        val title = TextView(this).apply { text="🐔 Чікін склад"; textSize=28f; setPadding(0,0,0,20) }
        box.addView(title)
        listOf("Поголів'я" to ::birds, "Корм" to ::feed, "Яйця та продаж" to ::eggs, "Витрати" to ::expenses, "Окупність" to ::profit, "Півники / забій" to ::roosters, "Загальний звіт" to ::report).forEach { (s,f) ->
            val b=Button(this).apply { text=s; setOnClickListener { f() } }; box.addView(b, LinearLayout.LayoutParams(-1,60).apply{setMargins(0,5,0,5)})
        }
        setContentView(box)
    }

    private fun field(h:String, v:String=""): EditText = EditText(this).apply { hint=h; setText(v); inputType=2 }
    private fun save(k:String,v:String){ p.edit().putString(k,v).apply() }
    private fun num(k:String)=p.getString(k,"0")!!.replace(',','.').toDoubleOrNull()?:0.0
    private fun show(title:String, body:String){ AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK",null).show() }

    private fun birds(){
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,10,20,10)}
        val c=field("Кількість курей",p.getString("chickens","")); val r=field("Кількість півнів",p.getString("roosters","")); val d=field("Дата народження (дд.мм.рррр)",p.getString("birth",""))
        listOf(c,r,d).forEach{l.addView(it)}
        AlertDialog.Builder(this).setTitle("Поголів'я").setView(l).setPositiveButton("Зберегти"){_,_->save("chickens",c.text.toString());save("roosters",r.text.toString());save("birth",d.text.toString())}.setNegativeButton("Скасувати",null).show()
    }
    private fun feed(){
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,10,20,10)}
        val g=field("Корм на 1 курку, г/день",p.getString("grams","")); val price=field("Ціна корму, грн/кг",p.getString("feedPrice","")); l.addView(g);l.addView(price)
        AlertDialog.Builder(this).setTitle("Корм").setView(l).setPositiveButton("Розрахувати"){_,_->save("grams",g.text.toString());save("feedPrice",price.text.toString()); val kg=num("chickens")*num("grams")*30/1000; show("Корм за місяць","Потрібно: %.2f кг\nВартість: %.2f грн".format(kg,kg*num("feedPrice")))}.setNegativeButton("Скасувати",null).show()
    }
    private fun eggs(){
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,10,20,10)}; val e=field("Яєць за місяць",p.getString("eggs","")); val pr=field("Ціна за 10 яєць, грн",p.getString("eggPrice",""));l.addView(e);l.addView(pr)
        AlertDialog.Builder(this).setTitle("Яйця та продаж").setView(l).setPositiveButton("Зберегти"){_,_->save("eggs",e.text.toString());save("eggPrice",pr.text.toString())}.setNegativeButton("Скасувати",null).show()
    }
    private fun expenses(){ val x=field("Інші витрати за місяць, грн",p.getString("other","")); AlertDialog.Builder(this).setTitle("Витрати").setView(x).setPositiveButton("Зберегти"){_,_->save("other",x.text.toString())}.setNegativeButton("Скасувати",null).show() }
    private fun profit(){
        val feed=num("chickens")*num("grams")*30/1000*num("feedPrice"); val rev=num("eggs")/10*num("eggPrice"); val exp=feed+num("other"); show("Окупність","Дохід: %.2f грн/міс\nВитрати: %.2f грн/міс\nПрибуток: %.2f грн/міс".format(rev,exp,rev-exp))
    }
    private fun roosters(){ val x=field("Дата планового забою (дд.мм.рррр)",p.getString("slaughter","")); AlertDialog.Builder(this).setTitle("Півники / забій").setMessage("Для м'ясних півників термін залежить від породи та ваги. Орієнтуйся насамперед на живу масу і стан птиці.").setView(x).setPositiveButton("Зберегти"){_,_->save("slaughter",x.text.toString())}.setNegativeButton("Скасувати",null).show() }
    private fun report(){ val feed=num("chickens")*num("grams")*30/1000; val cost=feed*num("feedPrice"); val rev=num("eggs")/10*num("eggPrice"); show("Загальний звіт","Кури: ${num("chickens").toInt()}\nПівні: ${num("roosters").toInt()}\nКорм: %.2f кг/міс\nКорм: %.2f грн/міс\nЯйця: %.0f/міс\nДохід: %.2f грн/міс\nІнші витрати: %.2f грн/міс".format(feed,cost,num("eggs"),rev,num("other"))) }
}
